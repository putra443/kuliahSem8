import java.util.*;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RamaFS
 */
public class Knight {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String N = sc.next();
        char[] arr = new char[N.length()];
        for (int i = 0; i<N.length(); i++){
            arr[i]=N.charAt(i);
        }
        for (int i = 0; i<N.length(); i++){
            
        }
    }
}
